import express from "express";
import cors from "cors";
import * as cheerio from "cheerio";
import { URL } from "node:url";

const app = express();
const PORT = process.env.PORT || 10000;

app.use(cors({ origin: true }));
app.use(express.json({ limit: "200kb" }));

const SENSITIVE_PATTERNS = [
  /acompanhantes?/i, /escort/i, /garota.?com.?local/i, /gsexy/i, /erosguia/i,
  /splove/i, /photoacompanhantes/i, /massagem.?erot/i, /sexo/i, /swing/i
];

function isSensitiveTarget(url){
  return SENSITIVE_PATTERNS.some(rx => rx.test(url));
}
function normalizePhone(raw){
  const digits = String(raw||"").replace(/\D/g,"");
  if(digits.length < 10 || digits.length > 15) return "";
  return digits;
}
function normalizeEmail(raw){
  return String(raw||"").trim().toLowerCase();
}
function sameHost(a,b){
  try{return new URL(a).host === new URL(b).host}catch{return false}
}
function absolute(href, base){
  try{return new URL(href, base).href}catch{return null}
}
function eligibleBusinessPage(url, html){
  const u = url.toLowerCase();
  const pageSignal = /(contact|contato|fale-conosco|about|sobre|empresa|atendimento)/.test(u);
  const businessSignal = /LocalBusiness|Organization|Corporation|ProfessionalService|Store/i.test(html);
  return pageSignal || businessSignal;
}
function extractContacts(html, sourceUrl, city){
  const $ = cheerio.load(html);
  const contacts = [];
  const push = (type,value) => {
    if(!value) return;
    contacts.push({ type, value, sourceUrl, city });
  };

  $("a[href^='tel:']").each((_,el)=>{
    const v = normalizePhone($(el).attr("href").slice(4));
    if(v) push("phone",v);
  });
  $("a[href^='mailto:']").each((_,el)=>{
    const v = normalizeEmail($(el).attr("href").slice(7).split("?")[0]);
    if(v) push("email",v);
  });

  const text = $("body").text().replace(/\s+/g," ");
  for(const m of text.matchAll(/(?:\+?55[\s.-]?)?(?:\(?\d{2}\)?[\s.-]?)?(?:9?\d{4})[\s.-]?\d{4}/g)){
    const v = normalizePhone(m[0]);
    if(v) push("phone",v);
  }
  for(const m of text.matchAll(/[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/ig)){
    push("email", normalizeEmail(m[0]));
  }
  return contacts;
}
async function fetchPage(url){
  const ctrl = new AbortController();
  const t = setTimeout(()=>ctrl.abort(), 12000);
  try{
    const r = await fetch(url,{
      signal:ctrl.signal,
      redirect:"follow",
      headers:{
        "User-Agent":"LeadCollectorAI/2.0 (+business-contact-research)",
        "Accept":"text/html,application/xhtml+xml"
      }
    });
    const type = r.headers.get("content-type") || "";
    if(!r.ok || !type.includes("text/html")) return null;
    return await r.text();
  }finally{
    clearTimeout(t);
  }
}

app.get("/health", (_,res)=>res.json({ok:true, service:"Lead Collector AI API", version:"2.0"}));

app.post("/api/collect", async(req,res)=>{
  try{
    const target = String(req.body?.url || "").trim();
    const city = String(req.body?.city || "").trim();
    const maxPages = Math.max(1, Math.min(50, Number(req.body?.maxPages || 20)));

    let start;
    try{ start = new URL(target); }catch{
      return res.status(400).json({error:"URL inválida."});
    }
    if(!["http:","https:"].includes(start.protocol)){
      return res.status(400).json({error:"Somente URLs HTTP/HTTPS são aceitas."});
    }
    if(isSensitiveTarget(target)){
      return res.status(403).json({
        error:"Este domínio/categoria foi bloqueado porque envolve dados pessoais sensíveis. Use a ferramenta apenas para contatos públicos de negócios e organizações."
      });
    }

    const queue = [start.href];
    const visited = new Set();
    const contacts = [];
    const seenContacts = new Set();

    while(queue.length && visited.size < maxPages){
      const current = queue.shift();
      if(visited.has(current) || !sameHost(current, start.href)) continue;
      if(isSensitiveTarget(current)) continue;

      visited.add(current);
      const html = await fetchPage(current).catch(()=>null);
      if(!html) continue;

      if(eligibleBusinessPage(current, html)){
        for(const c of extractContacts(html,current,city)){
          const key = `${c.type}:${c.value}`;
          if(!seenContacts.has(key)){
            seenContacts.add(key); contacts.push(c);
          }
        }
      }

      const $ = cheerio.load(html);
      $("a[href]").each((_,el)=>{
        const href = absolute($(el).attr("href"), current);
        if(!href || visited.has(href) || !sameHost(href,start.href)) return;
        const u = href.split("#")[0];
        if(/\.(jpg|jpeg|png|gif|webp|svg|pdf|zip|mp4|mp3)$/i.test(u)) return;
        if(queue.length < maxPages * 4) queue.push(u);
      });
    }

    res.json({
      status:"success",
      target:start.href,
      pagesVisited:visited.size,
      contacts
    });
  }catch(err){
    res.status(500).json({error: err?.message || "Erro interno."});
  }
});

app.listen(PORT, ()=>console.log(`Lead Collector AI API online na porta ${PORT}`));